﻿namespace PRO2_DABD1249321
{
    partial class MatrizForm
    {
        string[,] DataCSV;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent(string[,] MatrizParaLeer)
        {
            this.DataCSV = MatrizParaLeer;

            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MatrizForm));

            this.SuspendLayout();
            // 
            // MatrizForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Name = "MatrizForm";
            this.Text = "Diseño de bodega";
            this.ResumeLayout(false);

            int n_fila = DataCSV.GetLength(0);
            int n_columna = DataCSV.GetLength(1);
            for (int o = 0; o < n_fila; o++)
            {
                for (int x = 0; x < n_columna; x++)
                {
                    this.PB0_0 = new System.Windows.Forms.PictureBox();
                    //((System.ComponentModel.ISupportInitialize)(this.PB0_0)).BeginInit();
                    this.Controls.Add(this.PB0_0);
                    this.PB0_0.BackColor = DataCSV[o,x]=="P"?System.Drawing.SystemColors.ControlDark: System.Drawing.SystemColors.ControlLight;
                    this.PB0_0.BackColor = DataCSV[o, x] == "C" ? System.Drawing.Color.SkyBlue : System.Drawing.SystemColors.ControlLight;
                    this.PB0_0.BackColor = DataCSV[o, x] == "F" ? System.Drawing.Color.Red : System.Drawing.SystemColors.ControlLight;
                    this.PB0_0.BackColor = DataCSV[o, x] == "N" ? System.Drawing.Color.RosyBrown : System.Drawing.SystemColors.ControlLight;
                    //this.PB0_0.Image = ;
                    this.PB0_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                    this.PB0_0.Enabled = false;
                    this.PB0_0.Location = new System.Drawing.Point(x*100, o*100);
                    this.PB0_0.Name = "PB0_"+MatrizParaLeer[o,x];
                    this.PB0_0.Size = new System.Drawing.Size(100, 100);
                    this.PB0_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                    this.PB0_0.TabIndex = 0;
                    this.PB0_0.TabStop = false;

                    


                }
            }
          
            this.BT0_1 = new System.Windows.Forms.Button();
            this.Controls.Add(this.BT0_1);
            //((System.ComponentModel.ISupportInitialize)(this.BT0_1)).BeginInit();
            this.BT0_1.Location = new System.Drawing.Point(500, 575);
            this.BT0_1.Text = "Entrada";
            this.BT0_1.Name = "Boton_1";
            //this.BT0_1.Enabled = false;
            this.BT0_1.Size = new System.Drawing.Size(89, 50);
            this.BT0_1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BT0_1.Click += new System.EventHandler(this.BT0_1_Click);

            this.BT0_2 = new System.Windows.Forms.Button();
            this.Controls.Add(this.BT0_2);
            //((System.ComponentModel.ISupportInitialize)(this.BT0_1)).BeginInit();
            this.BT0_2.Location = new System.Drawing.Point(600, 575);
            this.BT0_2.Text = "Salida";
            this.BT0_2.Name = "Boton_1";
            //this.BT0_2.Enabled = false;
            this.BT0_2.Size = new System.Drawing.Size(89, 50);
            this.BT0_2.BackColor = System.Drawing.SystemColors.ControlDarkDark;

        }
        private System.Windows.Forms.PictureBox PB0_0;
        private System.Windows.Forms.PictureBox PB0_1;
        private System.Windows.Forms.Button BT0_1;
        private System.Windows.Forms.Button BT0_2;
        #endregion
    }
}